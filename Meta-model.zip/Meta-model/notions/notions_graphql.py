from ariadne import QueryType, ObjectType, EnumType, ScalarType, gql
from ariadne import make_executable_schema
from ariadne.asgi import GraphQL
import uvicorn
from enum import IntEnum
from datetime import date, datetime
import dateutil
import inspect

class NotionType(IntEnum):
    BOOLEAN = 1
    DATE = 2
    INTEGER = 3
    FLOAT = 4

class NotionUnit(IntEnum):
    DAY = 1
    WEEK = 2
    MONTH = 3
    YEAR = 4

class AgeClass(IntEnum):
    CHILD = 1
    ADULT = 2

class NotionFrame:
    frames = dict()

    def __init__(self, name: str, type: NotionType, unit: NotionUnit, converter: callable, discriminator: callable) -> None:
        self.name = name
        self.type = type
        self.unit = unit
        self.converter = converter
        self.discriminator = discriminator
        self.frames[name] = self

    def get_notion_frame(name: str) -> object:
        return NotionFrame.frames[name]
    
    def get_callable_as_string(self, f: callable) -> any:
        code, length = inspect.getsourcelines(f)
        return f"{code[0]}"

class NotionValue:
    def __init__(self, id: str, frame_name: str) -> None:
        self.id = id
        self.frame_name = frame_name
        self.frame = NotionFrame.get_notion_frame(frame_name)
            

nf_legal_age = NotionFrame(
    name = "legal_age",
    type = NotionType.INTEGER,
    unit = NotionUnit.YEAR,
    converter = lambda args: int((args['actual_date'] - args['birth_date']).days//365.24),
    discriminator = lambda age: AgeClass.CHILD if age < 18 else AgeClass.ADULT
)

type_defs = gql(
    '''
    scalar Datetime
    
    type Query {
        notionFrames: [NotionFrame!]!
        notionFrame(name: String!): NotionFrame
        legalAge(frameName: String!, birthDate: Datetime, actualDate: Datetime): Int
    }
    
    """
    A description of how an observer evaluates sensory stimuli or measurements.
    """
    type NotionFrame {
        name: ID!
        type: NotionType
        unit: NotionUnit
        converter: String
        discriminator: String
    }
    
    enum NotionType {
        BOOLEAN
        DATE
        INTEGER
        FLOAT
    }
                
    enum NotionUnit {
        DAY
        WEEK
        MONTH
        YEAR
    }
    '''
)

query = QueryType()
# mutation = MutationType()
notion_frame = ObjectType("NotionFrame")
# notion_value = ObjectType("NotionValue")
notion_type = EnumType(
    "NotionType",
    {
        "BOOLEAN": 1,
        "DATE": 2,
        "INTEGER": 3,
        "FLOAT" : 4,
    }
)
notion_unit = EnumType(
    "NotionUnit",
    {
        "DAY": 1,
        "WEEK": 2,
        "MONTH": 3,
        "YEAR" : 4,
    }
)
datetime_scalar = ScalarType("Datetime")

@datetime_scalar.serializer
def serialize_datetime(value):
    return value.isoformat()

@datetime_scalar.value_parser
def parse_datetime_value(value):
    # dateutil is provided by python-dateutil library
    if value:
        return dateutil.parser.parse(value)

@datetime_scalar.literal_parser
def parse_datetime_literal(ast):
    value = str(ast.value)
    return parse_datetime_value(value)  # reuse logic from parse_value

@query.field("notionFrames")
def resolve_notion_frames(*_) -> list[NotionFrame]:
    return [nf for nf in NotionFrame.frames.values()]

@query.field("notionFrame")
def resolve_notion_frame(*_, name: str) -> NotionFrame:
    return NotionFrame.get_notion_frame(name)

@query.field("legalAge")
def resolve_legal_age(*_, frameName: str, birthDate: datetime, actualDate: datetime) -> int:
    nf = NotionFrame.get_notion_frame(frameName)
    args = dict()
    args["birth_date"] = parse_datetime_value(birthDate)
    args["actual_date"] = parse_datetime_value(actualDate)
    return nf.converter(args)

@notion_frame.field("name")
def resolve_notion_frame_name(obj: NotionFrame, *_) -> str:
    return obj.name

@notion_frame.field("type")
def resolve_notion_frame_type(obj: NotionFrame, *_) -> NotionType:
    return obj.type

@notion_frame.field("unit")
def resolve_notion_frame_unit(obj: NotionFrame, *_) -> NotionUnit:
    return obj.unit

@notion_frame.field("converter")
def resolve_notion_frame_converter(obj: NotionFrame, *_) -> str:
    return obj.get_callable_as_string(obj.converter)

@notion_frame.field("discriminator")
def resolve_notion_frame_discriminator(obj: NotionFrame, *_) -> str:
    return obj.get_callable_as_string(obj.discriminator)

schema = make_executable_schema(type_defs, query, notion_frame, notion_type, notion_unit)

app = GraphQL(schema, debug=True)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)