from setuptools import setup

setup(
   name='notions',
   version='1.0',
   description='A notions module',
   author='Peter Willems',
   author_email='peter.willems@infrabim.nl',
   packages=['notions'],  #same as name
   install_requires=['ariadne', 'uvicorn'], #external packages as dependencies
)