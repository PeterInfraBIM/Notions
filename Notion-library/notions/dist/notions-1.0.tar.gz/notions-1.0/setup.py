from setuptools import setup

setup(
    name='notions',
    version='1.0',
    description='Tool library for using notions',
    author="Peter Willems (infraBIM)",
    author_email='peter.willems@infrabim.nl',
    url='infrabim.nl',
    py_modules=['notions'],
)