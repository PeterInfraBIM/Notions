python setup.py sdist
cd dist
python -m pip install notions_legal-1.1.tar.gz