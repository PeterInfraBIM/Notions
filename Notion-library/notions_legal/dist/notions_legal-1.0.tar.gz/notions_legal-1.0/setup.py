from setuptools import setup

setup(
    name='notions_legal',
    version='1.0',
    description='legal notion frames',
    author="Peter Willems (infraBIM)",
    author_email='peter.willems@infrabim.nl',
    url='infrabim.nl',
    py_modules=['notions_legal'],
)