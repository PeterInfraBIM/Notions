from notions import NotionFrame, NotionType, NotionUnit, PerceptiveFrame, ConfigurationManagementClass
from enum import Enum

class OrientationClass(Enum):
    DEPARTURE = "DEPARTURE"
    ARRIVAL = "ARRIVAL"

class BoundaryClass(Enum):
    BOUNDS = "BOUNDS"
    IS_BOUNDED_BY = "IS_BOUNDED_BY"

class EnclosureClass(Enum):
    ENCLOSES = "ENCLOSE"
    IS_ENCLOSED_BY = "IS_ENCLOSED_BY"

class ConnectionClass(Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"

def init_link():
    def converter_function(args):
        return {"link": args["link"]}
    
    def discriminator_function(args):
        return None
    
    NotionFrame(
        id="NF_Link",
        parameter="link",
        type=NotionType.IRI, 
        unit=NotionUnit.NONE,
        derived_from=[],
        converter_code="""
    def converter_function(args):
        return {"link": args["link"]}
    """,
        converter=converter_function,
        discriminator_code="""
    def discriminator_function(args):
        return None
    """,
        discriminator=discriminator_function
    )

def init_orientation():
    def converter_function(args):
        return {"orientation": args["orientation"]}
    
    def discriminator_function(args):
        return OrientationClass(args["orientation"])
    
    NotionFrame(
        id="NF_Orientation",
        parameter="orientation",
        type=NotionType.ENUMERATION, 
        unit=NotionUnit.NONE,
        derived_from=["NF_Link"],
        converter_code="""
    def converter_function(args):
        return {"orientation": args["orientation"]}
    """,
        converter=converter_function,
        discriminator_code="""
    def discriminator_function(args):
        return OrientationClass(args["orientation"])
    """,
        discriminator=discriminator_function
    )

def init_boundary():
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
        if orientation.name is OrientationClass.DEPARTURE.name:
            return {"boundary": BoundaryClass.IS_BOUNDED_BY.name}
        else:
            return {"boundary": BoundaryClass.BOUNDS.name}
    
    def discriminator_function(args):
        return args["boundary"]
    
    NotionFrame(
        id="NF_Boundary",
        parameter="boundary",
        type=NotionType.ENUMERATION, 
        unit=NotionUnit.NONE,
        derived_from=["NF_Orientation"],
        converter_code="""
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
        if orientation.name is OrientationClass.DEPARTURE.name:
            return {"boundary": BoundaryClass.IS_BOUNDED_BY.name}
        else:
            return {"boundary": BoundaryClass.BOUNDS.name}
    """,
        converter=converter_function,
        discriminator_code="""
    def discriminator_function(args):
        return args["boundary"]
    """,
        discriminator=discriminator_function
    )

def init_enclosure():
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
        if orientation.name is OrientationClass.DEPARTURE.name:
            return {"enclosure": EnclosureClass.IS_ENCLOSED_BY.name}
        else:
            return {"enclosure": EnclosureClass.ENCLOSES.name}
    
    def discriminator_function(args):
        return args["enclosure"]
    
    NotionFrame(
        id="NF_Enclosure",
        parameter="enclosure",
        type=NotionType.ENUMERATION, 
        unit=NotionUnit.NONE,
        derived_from=["NF_Orientation"],
        converter_code="""
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
            if orientation.name is OrientationClass.DEPARTURE.name:
                return {"enclosure": EnclosureClass.IS_ENCLOSED_BY.name}
            else:
                return {"enclosure": EnclosureClass.ENCLOSES.name}
    """,
        converter=converter_function,
        discriminator_code="""
    def discriminator_function(args):
        return args["enclosure"]
    """,
        discriminator=discriminator_function
    )

def init_connection():
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
        if orientation.name is OrientationClass.DEPARTURE.name:
            return {"connection": ConnectionClass.MALE.name}
        else:
            return {"connection": ConnectionClass.FEMALE.name}
    
    def discriminator_function(args):
        return args["connection"]
    
    NotionFrame(
        id="NF_Connection",
        parameter="connection",
        type=NotionType.ENUMERATION, 
        unit=NotionUnit.NONE,
        derived_from=["NF_Orientation"],
        converter_code="""
    def converter_function(args):
        orientation = OrientationClass(args["orientation"])
        if orientation.name is OrientationClass.DEPARTURE.name:
            return {"connection": ConnectionClass.MALE.name}
        else:
            return {"connection": ConnectionClass.FEMALE.name}
    """,
        converter=converter_function,
        discriminator_code="""
    def discriminator_function(args):
        return args["connection"]
    """,
        discriminator=discriminator_function
    )

def init_config_mng_relation():
    def discriminator_function(notion_frames, notion_values):
        print(f"Number of notion frames: {len(NotionFrame.frames)}")
        if notion_values.get("NF_Enclosure"):
            enclosures = [nv for nv in notion_values.get("NF_Enclosure")]
            if enclosures:
                if enclosures[0].property.get("enclosure") == "IS_ENCLOSED_BY" and \
                    enclosures[1].property.get("enclosure") == "ENCLOSES":
                    return ConfigurationManagementClass("NODE_NODE_ENCLOSURE")
                else:
                    return None
        if notion_values.get("NF_Boundary"):
            boundaries = [nv for nv in notion_values.get("NF_Boundary")]
            if boundaries:
                if boundaries[0].property.get("boundary") == "IS_BOUNDED_BY" and \
                    boundaries[1].property.get("boundary") == "BOUNDS":
                    return ConfigurationManagementClass("NODE_PORT_BOUNDARY")
                else:
                    return None
        if notion_values.get("NF_Connection"):
            connections = [nv for nv in notion_values.get("NF_Connection")]
            if connections:
                if connections[0].property.get("connection") == "MALE" and \
                    connections[1].property.get("connection") == "FEMALE":
                    return ConfigurationManagementClass("NODE_NODE_CONNECTION")
                else:
                    return None
                
    PerceptiveFrame(
        id="PF_Config_Mng_Relation",
        notion_frame_names=["NF_Enclosure", "NF_Boundary", "NF_Connection"],
        discriminator_code="""
def discriminator_function(notion_frames, notion_values):
    print(f"Number of notion frames: {len(NotionFrame.frames)}")
    if notion_values.get("NF_Enclosure"):
        enclosures = [nv for nv in notion_values.get("NF_Enclosure")]
        if enclosures:
            if enclosures[0].property.get("enclosure") == "IS_ENCLOSED_BY" and \
                enclosures[1].property.get("enclosure") == "ENCLOSES":
                return ConfigurationManagementClass("NODE_NODE_ENCLOSURE")
            else:
                return None
    if notion_values.get("NF_Boundary"):
        boundaries = [nv for nv in notion_values.get("NF_Boundary")]
        if boundaries:
            if boundaries[0].property.get("boundary") == "IS_BOUNDED_BY" and \
                boundaries[1].property.get("boundary") == "BOUNDS":
                return ConfigurationManagementClass("NODE_PORT_BOUNDARY")
            else:
                return None
    if notion_values.get("NF_Connection"):
        connections = [nv for nv in notion_values.get("NF_Connection")]
        if connections:
            if connections[0].property.get("connection") == "MALE" and \
                connections[1].property.get("connection") == "FEMALE":
                return ConfigurationManagementClass("NODE_NODE_CONNECTION")
            else:
                return None
""",
        discriminator=discriminator_function
    )


def init():
    init_link()
    init_orientation()
    init_boundary()
    init_enclosure()
    init_connection()
    init_config_mng_relation()
