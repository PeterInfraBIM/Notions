python setup.py sdist
cd dist
python -m pip install notions_topology-1.1.tar.gz